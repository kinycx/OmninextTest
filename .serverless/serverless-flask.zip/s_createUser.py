import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='kinycx',
    application_name='serverless-flask',
    app_uid='LVjGpl0pdn4RtByMYl',
    org_uid='0aeb0cad-d4e3-4a43-b36f-ec681edac5a3',
    deployment_uid='9b83a658-2b2a-4510-94bd-bd2350a4b76f',
    service_name='serverless-flask',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.0.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-dev-createUser', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
